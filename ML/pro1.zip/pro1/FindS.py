

import csv

a=[]
print("\n the Given Training data set \n")
csvfile = open('ram.csv','r')
reader=csv.reader(csvfile)
for row in reader:
     a.append(row)
     print(row)

print("\n The total number of training instances are :",len(a))     
 
num_attributes=len(a[0])-1    


hypothesis = ['0'] * num_attributes
print("\n The initial value of Hypothesis : ",hypothesis)

for j in range(0,len(a)):
    hypothesis[j]=a[0][j]

for i in range(0,len(a)):
    if a[i][num_attributes]=='yes':
        for j in range(0,num_attributes):
            if a[i][j]==hypothesis[j] or hypothesis[j]=='0':
                hypothesis[j]=a[i][j]
            else:
                hypothesis[j]='?'
    print(" For Training instance N0 : {0} the Hypothesis is ".format(i+1),hypothesis)     
print("\n The Maximally Specific Hypothesis for a given Training Example :", hypothesis)
